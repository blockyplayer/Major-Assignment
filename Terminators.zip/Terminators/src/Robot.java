import java.util.*;
import java.io.File;

public class Robot {
	double health;
	double damage;
	int attackIndex;

	// Ordered in ascending attack damage dealt
	String[] attackTypes = { "1: Basic shoot", "2: Laser eyes", "3: Missile launch", "4: Defend" };;
	int[] attackTypesIndexes;
	boolean isAlive;

	public Robot(double health_, double damage_, int attackIndex_) {
		health = health_;

		// The attack array is in order of attack damage dealt, so we can directly use
		// the
		// index in calculations.
		damage = damage_ * (attackIndex_ + 1);
		attackIndex = attackIndex_;
		isAlive = true;

	}

	public void attack(Robot other) {
		if (canAttack(other)) {
			other.isAlive = false;
		} else {
			this.isAlive = false;
		}
	}

	public boolean canAttack(Robot other) {
		double damageThreshehold = (other.damage / 5);
		if (health > other.health && damage > damageThreshehold) {
			return true;
		}
		return false;
	}

	public void defend(Robot other) {
		if (this.canAttack(other) == false) {
			isAlive = false;
		}
	}

	public void fileIO() {
		Scanner scanner = new Scanner(new File("user-data.csv"));
		scanner.nextLine();
		scanner.useDelimiter(",");
		
		PrintWriter writer - new Printwriter(new File("analysis.txt"));
		
		while (scanner.hasNextLine()) {
			int attackIDData = scanner.nextInt();
			int attackIndexData = scanner.nextInt();
			String attackTypeData = scanner.next();
			Scanner.nextLine();
			
	        
            if(homeScore > awayScore) {
                writer.println(homeTeam+" won at home against "+awayTeam+" by "+homeScore+" - "+awayScore);
            }
            else if(homeScore < awayScore) {
                writer.println(awayTeam+" won away from home against "+homeTeam+" by "+awayScore+" - "+homeScore);
            }
            else {
                writer.println(homeTeam+" drew at home against "+awayTeam+" with full time score of "+homeScore+" - "+awayScore);
            }
        }

        scanner.close();
        writer.close();
		}

}

// Add method to write recent attacks to file

// Add method canAttack for File I/O to store recent attacks.
// Return false if attackIndex is in file between lines (file.length - 1) and
// (file.length - 3)
// Return true otherwise. Also move the health and damageThreshehold check here.
